# capstone-easyclaim-backend
Backend code for easycliam application
The backend code is written in java
